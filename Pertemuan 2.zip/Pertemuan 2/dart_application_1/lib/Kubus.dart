class Kubus {
  int s = 0;

  Kubus(int sisi) {
    this.s = sisi;
  }

  int getVolume() {
    return s * s * s;
  }

  int getLuasPermukaan() {
    return 6 * s * s;
  }
}
