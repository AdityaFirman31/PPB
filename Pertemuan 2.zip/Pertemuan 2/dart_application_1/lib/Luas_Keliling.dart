import 'dart:math';

// Class untuk Persegi
class Persegi {
  double sisi;

  Persegi(this.sisi);

  double hitungLuas() {
    return sisi * sisi;
  }

  double hitungKeliling() {
    return 4 * sisi;
  }
}

// Class untuk Segitiga
class Segitiga {
  double alas;
  double tinggi;
  double sisi1, sisi2, sisi3;

  Segitiga(this.alas, this.tinggi, this.sisi1, this.sisi2, this.sisi3);

  double hitungLuas() {
    return 0.5 * alas * tinggi;
  }

  double hitungKeliling() {
    return sisi1 + sisi2 + sisi3;
  }
}

// Class untuk Lingkaran
class Lingkaran {
  double jariJari;

  Lingkaran(this.jariJari);

  double hitungLuas() {
    return pi * jariJari * jariJari;
  }

  double hitungKeliling() {
    return 2 * pi * jariJari;
  }
}

// Class untuk Kubus
class Kubus {
  double sisi;

  Kubus(this.sisi);

  double hitungLuasPermukaan() {
    return 6 * sisi * sisi;
  }

  double hitungVolume() {
    return sisi * sisi * sisi;
  }
}

void main() {
  // Membuat objek (object) dan menampilkan hasilnya
  var persegi = Persegi(5.0);
  print("--- Persegi ---");
  print("Luas: ${persegi.hitungLuas()}");
  print("Keliling: ${persegi.hitungKeliling()}");
  print("\n");

  var segitiga = Segitiga(4.0, 3.0, 3.0, 4.0, 5.0);
  print("--- Segitiga ---");
  print("Luas: ${segitiga.hitungLuas()}");
  print("Keliling: ${segitiga.hitungKeliling()}");
  print("\n");

  var lingkaran = Lingkaran(7.0);
  print("--- Lingkaran ---");
  print("Luas: ${lingkaran.hitungLuas()}");
  print("Keliling: ${lingkaran.hitungKeliling()}");
  print("\n");

  var kubus = Kubus(4.0);
  print("--- Kubus ---");
  print("Luas Permukaan: ${kubus.hitungLuasPermukaan()}");
  print("Volume: ${kubus.hitungVolume()}");
}
