void main() {
  Mahasiswa mhs = new Mahasiswa();
  mhs.nim = "A11.2022.14134";
  mhs.nama = "Aditya Firman Gani";
  mhs.IPK = 3.5;
  mhs.view();

  Mahasiswa mhs1 = new Mahasiswa.a("A11.2022.14134", "Aditya Firman Gani", 3.5);
  mhs1.view();
}

class Mahasiswa {
  String nim = "";
  String nama = "";
  double IPK = 0;

  Mahasiswa() {
    print("~~ Data Mahasiswa ~~");
  }

  // Named constructor
  Mahasiswa.a(String nim, String nama, double IPK) {
    this.nim = nim;
    this.nama = nama;
    this.IPK = IPK;
  }

  void view() {
    print("Nim   : $nim");
    print("Nama  : $nama");
    print("IPK   : $IPK");
  }
}
