import 'Persegi.dart';

void main() {
  Persegi p = new Persegi(20, 10);

  int luas = p.getLuas();
  int keliling = p.getKeliling();

  print('Luas : $luas');
  print('Keliling : $keliling');
}
