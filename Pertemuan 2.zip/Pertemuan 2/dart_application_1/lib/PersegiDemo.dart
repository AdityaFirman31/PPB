// PersegiDemo.dart

import 'Persegi.dart';

void main() {
  Persegi p = new Persegi(20, 10);
  int luas = p.getLuas();
  print('Luas: $luas');
}
