import 'dart:io';

class nilaiPPB {
  String nim = '';
  String nama = '';
  String nHuruf = '';
  String predikat = '';

  double nilaiUts = 0;
  double nilaiTugas = 0;
  double nilaiUas = 0;
  double pNilaiUts = 0;
  double pNilaiTugas = 0;
  double pNilaiUas = 0;
  double nilaiAkhir = 0;

  nilaiPPB() {
    print('~v~ Nilai Mahasiswa PPB ~v~');
  }

  void inputmhs() {
    stdout.write('NIM             : ');
    nim = stdin.readLineSync()!;
    stdout.write('Nama            : ');
    nama = stdin.readLineSync()!;
    stdout.write('N. Tugas [0-100]: ');
    nilaiTugas = double.parse(stdin.readLineSync()!);
    stdout.write('N. UTS   [0-100]: ');
    nilaiUts = double.parse(stdin.readLineSync()!);
    stdout.write('N. UAS   [0-100]: ');
    nilaiUas = double.parse(stdin.readLineSync()!);
  }

  void hitungnilai() {
    pNilaiTugas = 0.35 * nilaiTugas;
    pNilaiUts = 0.30 * nilaiUts;
    pNilaiUas = 0.35 * nilaiUas;
    nilaiAkhir = pNilaiUts + pNilaiTugas + pNilaiUas;

    if (nilaiAkhir >= 80) {
      nHuruf = 'A';
      predikat = 'Sangat Baik';
    } else if (nilaiAkhir >= 70) {
      nHuruf = 'B';
      predikat = 'Baik';
    } else if (nilaiAkhir >= 60) {
      nHuruf = 'C';
      predikat = 'Cukup';
    } else if (nilaiAkhir >= 50) {
      nHuruf = 'D';
      predikat = 'Kurang';
    } else {
      nHuruf = 'E';
      predikat = 'Gagal';
    }
  }

  void cetakNilai() {
    print('=================================');
    print('          HASIL PERHITUNGAN      ');
    print('=================================');
    print('NIM             : $nim');
    print('Nama            : $nama');
    print('Nilai Akhir     : ${nilaiAkhir.toStringAsFixed(2)}');
    print('Nilai Huruf     : $nHuruf');
    print('Predikat        : $predikat');
    print('=================================');
  }
}
