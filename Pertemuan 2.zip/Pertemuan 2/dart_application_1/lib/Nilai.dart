class NilaiMahasiswa {
  // Atribut
  String nim;
  String nama;
  double nilaiUts;
  double nilaiTugas;
  double nilaiUas;
  double pNilaiUts = 0.0;
  double pNilaiTugas = 0.0;
  double pNilaiUas = 0.0;
  double nilaiAkhir = 0.0;
  String nHuruf = "";
  String predikat = "";

  NilaiMahasiswa(
      this.nim, this.nama, this.nilaiUts, this.nilaiTugas, this.nilaiUas) {
    hitungNilai();
    getNilaiHuruf();
    getPredikat();
  }

  // Method
  void hitungNilai() {
    pNilaiUts = 0.30 * nilaiUts; // 30% dari nilaiUts [cite: 116, 117]
    pNilaiTugas = 0.35 * nilaiTugas; // 35% dari nilaiTugas [cite: 118]
    pNilaiUas = 0.35 * nilaiUas; // 35% dari nilaiUas [cite: 119, 127]
    nilaiAkhir = pNilaiUts + pNilaiTugas + pNilaiUas;
  }

  void getNilaiHuruf() {
    if (nilaiAkhir >= 80) {
      nHuruf = "A";
    } else if (nilaiAkhir >= 70) {
      nHuruf = "B";
    } else if (nilaiAkhir >= 60) {
      nHuruf = "C";
    } else if (nilaiAkhir >= 50) {
      nHuruf = "D";
    } else {
      nHuruf = "E";
    }
  }

  void getPredikat() {
    if (nHuruf == "A") {
      predikat = "Sangat Baik";
    } else if (nHuruf == "B") {
      predikat = "Baik";
    } else if (nHuruf == "C") {
      predikat = "Cukup";
    } else if (nHuruf == "D") {
      predikat = "Kurang";
    } else {
      predikat = "Sangat Kurang";
    }
  }

  void cetakNilai() {
    print("NIM         : $nim");
    print("Nama        : $nama");
    print("Nilai UTS   : $nilaiUts");
    print("Nilai Tugas : $nilaiTugas");
    print("Nilai UAS   : $nilaiUas");
    print("Nilai Akhir : $nilaiAkhir");
    print("Nilai Huruf : $nHuruf");
    print("Predikat    : $predikat");
  }
}

void main() {
  var mahasiswa = NilaiMahasiswa("10123456", "Doni Saputra", 85, 90, 88);
  mahasiswa.cetakNilai();
}
