abstract class Radio {
  void setGelombang(String gel);
}
