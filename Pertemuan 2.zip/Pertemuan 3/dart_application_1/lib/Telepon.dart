class Telepon {
  int nomer = 0;

  void telpon() {
    print("Sedang Menelepon");
  }
}
