class Karyawan {
  String npp;
  String nama;
  String? alamat;
  int thnMasuk;

  // Asumsi tunjangan anak
  double tunjanganAnak = 500000;

  Karyawan(this.npp, this.nama, {this.thnMasuk = 2015});

  // Metode untuk di-override (atau bisa juga dibuat abstract jika Anda mau)
  double hitungTotalGaji() {
    return 0;
  }

  String deskripsi() {
    return 'NPP: $npp\nNama: $nama';
  }
}
