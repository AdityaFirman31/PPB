import 'mountainbike.dart';

void main() {
// Membuat object
  MountainBike mbike = new MountainBike();
// Memanggil method di object
  mbike.speedUp(10);
  mbike.changeGear(2);
  mbike.setHeight(20);
}
