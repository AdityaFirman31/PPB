void main() {
  int s;
  int luasPermukaan;
  int volume;

  s = 6;

  luasPermukaan = 6 * s * s;
  volume = s * s * s;

  print('Sisi (Rusuk)  : $s');
  print('Luas Permukaan: $luasPermukaan');
  print('Volume        : $volume');
}
