import 'dart:math';

void main() {
  double r;
  double luas;
  double keliling;

  r = 14.0;

  luas = pi * pow(r, 2);
  keliling = 2 * pi * r;

  print('Jari-jari : $r');
  print('Luas      : ${luas.toStringAsFixed(2)}');
  print('Keliling  : ${keliling.toStringAsFixed(2)}');
}
