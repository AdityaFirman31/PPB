abstract class Kamera {
  void setPixel(double pixel);
  void ambilGambar();
}
