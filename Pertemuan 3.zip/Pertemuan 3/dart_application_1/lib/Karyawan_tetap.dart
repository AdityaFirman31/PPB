import 'Karyawan.dart';

class KaryawanTetap extends Karyawan {
  double gajiPokok;

  KaryawanTetap(String npp, String nama,
      {int thnMasuk = 2015, required this.gajiPokok})
      : super(npp, nama, thnMasuk: thnMasuk);

  @override
  double hitungTotalGaji() {
    return gajiPokok + tunjanganAnak;
  }

  @override
  String deskripsi() {
    return '''
${super.deskripsi()}
Status: Karyawan Tetap
Gaji Pokok: $gajiPokok
Tunjangan Anak: $tunjanganAnak
Total Gaji: ${hitungTotalGaji()}
''';
  }
}
