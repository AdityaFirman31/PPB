#include <iostream>

using namespace std;

int main()
{
    cout << "Nama         : Aditya Firman Gani" << endl;
    cout << "Nim          : A11.2022.14134" << endl;
    cout << "Alamat       : Kalipucang Kulon RT.04 RW.03" << endl;
    cout << "Asal Sekolah : SMK Muhammadiyah 3 Mayong" << endl;
    return 0;
}
