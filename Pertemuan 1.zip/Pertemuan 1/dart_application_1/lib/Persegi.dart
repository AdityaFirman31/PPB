void main() {
  int sisi;
  int luas;
  int keliling;

  sisi = 9;

  luas = sisi * sisi;
  keliling = 4 * sisi;

  print('Sisi     : $sisi');
  print('Luas     : $luas');
  print('Keliling : $keliling');
}
