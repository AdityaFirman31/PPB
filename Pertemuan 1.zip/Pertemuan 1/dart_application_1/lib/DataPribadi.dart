void main() {
  String nim = "A11.2022.14134";
  String nama = "Aditya Firman Gani";
  String alamat = "Jalan nakula raya no 66";
  String kota = "Semarang";
  String kodePos = "50132";
  String telp = "0893928394";
  String hp = "08923824723";
  String email = "hamzayuzen4@gmail.com";

  print("Nim           : $nim");
  print("Nama          : $nama");
  print("Alamat        : $alamat");
  print("Kota          : $kota");
  print("Kode Pos      : $kodePos");
  print("No Telephone  : $telp");
  print("No HP         : $hp");
  print("Email         : $email");
}
